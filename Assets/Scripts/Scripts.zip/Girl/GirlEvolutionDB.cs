﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using CsvHelper;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;

public class GirlEvolutionDB : MonoBehaviour
{
    public string addressableKey = "girls.csv"; // Addressables에서 등록한 csv 파일 주소
    public List<GirlEvolutionData> dataList = new List<GirlEvolutionData>();
    public Dictionary<int, GirlEvolutionData> dataByLevel = new Dictionary<int, GirlEvolutionData>();

    private async void Awake()
    {
        await LoadFromAddressablesAsync();
    }

    public async System.Threading.Tasks.Task LoadFromAddressablesAsync()
    {
        dataList.Clear();
        dataByLevel.Clear();
        Debug.Log("start");
        var handle = Addressables.LoadAssetAsync<TextAsset>(addressableKey);
        await handle.Task;

        if (handle.Status == AsyncOperationStatus.Succeeded)
        {
            string csvText = handle.Result.text;
            using (var reader = new StringReader(csvText))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                foreach (var record in csv.GetRecords<GirlEvolutionData>())
                {
                    dataList.Add(record);
                    dataByLevel[record.level] = record;
                }
            }
            dataList = dataList.OrderBy(d => d.level).ToList();
            Debug.Log($"[GirlEvolutionDB] Addressables CSV Loaded: {dataList.Count}개");
        }
        else
        {
            Debug.LogError("[GirlEvolutionDB] Addressables CSV Load Failed!");
        }
    }

    // 1부터만 반환
    public GirlEvolutionData GetDataByLevel(int level)
    {
        if (level < 1)
        {
            Debug.LogWarning($"[GirlEvolutionDB] level은 1 이상이어야 합니다. (요청: {level})");
            return null;
        }
        dataByLevel.TryGetValue(level, out var data);
        return data;
    }
}