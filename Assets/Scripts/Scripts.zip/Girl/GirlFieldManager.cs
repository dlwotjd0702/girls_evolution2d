﻿using System.Collections.Generic;
using UnityEngine;

public class GirlFieldManager : MonoBehaviour
{
    public GirlSpriteAddressableLoader spriteLoader;
    public GirlEvolutionDB evolutionDB;
    public GameObject girlPrefab;
    public Transform girlRoot;
    public GirlMergeManager mergeManager;

    public List<GirlCharacter> girlList = new List<GirlCharacter>();

    private async void Start()
    {
        // Addressables 데이터 모두 준비될 때까지 대기
        while (!spriteLoader.IsLoaded)
            await System.Threading.Tasks.Task.Yield();
        await evolutionDB.LoadFromAddressablesAsync();

        // 예시: 1~25레벨 자동 스폰
        for (int level = 1; level <= 25; level++)
        {
            SpawnGirl(level, new Vector2(level * 2f, 0)); // 원하는 위치로
        }
    }

    public void SpawnGirl(int level, Vector2 pos)
    {
        GirlEvolutionData evoData = evolutionDB.GetDataByLevel(level);
        if (evoData == null) return;

        Sprite sprite = null;
        spriteLoader.SpriteDict.TryGetValue(evoData.spriteName, out sprite);

        var go = Instantiate(girlPrefab, pos, Quaternion.identity, girlRoot);
        var girl = go.GetComponent<GirlCharacter>();
        girl.Init(evoData, sprite);

        if (mergeManager != null)
            girl.mergeManager = mergeManager;

        girlList.Add(girl);
    }
}